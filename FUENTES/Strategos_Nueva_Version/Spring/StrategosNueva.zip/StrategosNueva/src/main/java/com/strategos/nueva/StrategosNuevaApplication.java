package com.strategos.nueva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrategosNuevaApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrategosNuevaApplication.class, args);
	}

}
